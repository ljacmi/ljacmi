package hr.fer.oprpp1.hw08.jnotepadpp;

/**
 * Interface which models localization provider.
 * @author muham
 *
 */
public interface ILocalizationProvider {
	
	/**
	 * Adds new LocalizationListener 
	 * @param listener LocalizationListener that is added
	 */
	public void addLocalizationListener(ILocalizationListener listener);
	
	/**
	 * Removes some LocalizationListener.
	 * @param listener LocalizationListener that needs to be removed.
	 */
	public void removeLocalizationListener(ILocalizationListener listener);
	
	
	/**
	 * Returns the localized string for the given key and according to localization settings.
	 * @param key key for which the string is requested
	 * @return
	 */
	public String getString(String key);
	
	/**
	 * Returns the current language used for localization.
	 * @return
	 */
	
	public String getLanguage();
}
