package hr.fer.oprpp1.hw08.jnotepadpp;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Class which represents localization provider modeled as Singleton design pattern.
 * @author muham
 *
 */
public class LocalizationProvider extends AbstractLocalizationProvider{
	
	/**
	 * Language currently used by localization processes.
	 */
	private String language;
	
	/**
	 * Reference to ResourceBundle.
	 */
	
	private ResourceBundle bundle;
	
	/**
	 * Reference to the only instance of this class.
	 */
	
	private static final LocalizationProvider instance = new LocalizationProvider();
	
	/**
	 * Private constructor.
	 */
	private LocalizationProvider() {
		setLanguage("en");
	}

	@Override
	public String getString(String key) {
		return bundle.getString(key);
	}

	@Override
	public String getLanguage() {
		return this.language;
	}
	
	/**
	 *Method which sets the language used by localization processes. 
	 * @param language
	 */
	public void setLanguage(String language) {
		this.language = language;
		Locale locale = Locale.forLanguageTag(language);
		bundle = ResourceBundle.getBundle("hr.fer.oprpp1.hw08.jnotepadpp.prijevodi", locale);
		fire();
	}
	
	/**
	 * Returns the only instance of localization provider.
	 * @return
	 */
	
	public static LocalizationProvider getInstance() {
		return instance;
	}
	
	
}
