package hr.fer.oprpp1.hw08.jnotepadpp;

/**
 * Interface which represents localization listener.
 * @author muham
 *
 */
public interface ILocalizationListener {
	
	/**
	 * Method invoked when some localization setting has been changed.
	 */
	public void localizationChanged();
	
}
