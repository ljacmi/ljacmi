package hr.fer.oprpp1.hw08.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;

import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Collator;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;


import javax.swing.Action;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;






/**
 * Class which extends JFrame and represents a Notepad.
 * @author muham
 *
 */

public class JNotepadPP extends JFrame {

	private static final long serialVersionUID = 1L;
	/**
	 * menubar
	 */
	private JMenuBar menuBar;
	/**
	 * toolbar
	 */
	private JToolBar toolbar;
	
	/**
	 * statusBar
	 */
	
	private JPanel statusBar;
	
	/**
	 * Keeps reference to the MultipleDocument Model for which this JNotepaddPP 
	 * is created. 
	 */
	private MultipleDocumentModel documentModel;
	
	/**
	 * Keeps reference to FormLocalizationProvider used for localization purposes.
	 */
	
	public FormLocalizationProvider flp;
	
	/**
	 * String cashed by cutting of copying actions.
	 */
	
	private String tempCash;
	
	/**
	 * Reference to the current SingleDocumentModel.
	 */
	private SingleDocumentModel current;

	/**
	 * Action which represents opening of the document.
	 */
	private Action openDocumentAction;
	
	/**
	 * Action which represents saving the document.
	 */
	
	private Action saveDocumentAction;
	
	/**
	 * Action which represents saving the document as.
	 */
	
	private Action saveAsDocumentAction;
	
	/**
	 * Action which represents closing current tab in JNotepaddPP.
	 */
	
	private Action closeCurrentTabDocumentAction;
	
	/**
	 * Action which exits the JNotepadPP.
	 */
	private Action exitAction;
	
	/**
	 * Action which represents creating new document.
	 */
	
	private Action newDocumentAction;
	
	/**
	 * Action which represents cut action.
	 */
	private Action cutAction;
	
	/**
	 * Action which represents paste action.
	 */
	private Action pasteAction;
	
	/**
	 * Action which represents copy action.
	 */
	private Action copyAction;
	
	/**
	 * Action which retrieves statistics about the current file.
	 */
	private Action statsAction;
	
	/**
	 * Action which turns letters to capital versions of themselves.
	 */
	
	private Action changeCaseToUpperAction;
	
	/**
	 * Action which turns letters to non-capital versions of themselves.
	 */
	private Action changeCaseToLowerAction;
	
	/**
	 * Action which turns non-capital letters to capital versions of themselves and vice versa.
	 */
	
	private Action invertCaseAction;
	
	/**
	 * Action which represents sorting in ascending order.
	 */
	
	private Action sortAscendingAction;
	
	/**
	 * Action which represents sorting in descending order.
	 */
	
	private Action sortDescendingAction;
	
	/**
	 * Action which represents removing duplicate lines.
	 */
	
	private Action removeUniqueAction;

	public JNotepadPP() {
		super();
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent e) {


				exitAction.actionPerformed(null);

			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}
		});

		setLocation(0, 0);
		setSize(600, 600);

		flp = new FormLocalizationProvider(LocalizationProvider.getInstance(), this);

		openDocumentAction = new LocalizableAction("open", flp) {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.setDialogTitle("Open file");
				if(fc.showOpenDialog(JNotepadPP.this)!=JFileChooser.APPROVE_OPTION) {
					return;
				}
				File fileName = fc.getSelectedFile();
				Path filePath = fileName.toPath();
				if(!Files.isReadable(filePath)) {
					JOptionPane.showMessageDialog(
							JNotepadPP.this, 
							"Datoteka "+fileName.getAbsolutePath()+" ne postoji!", 
							"Pogreška", 
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				JNotepadPP.this.documentModel.loadDocument(filePath);
				titleChanged();
			}
		};


		saveAsDocumentAction = new LocalizableAction("saveAs", flp) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("Save document");
				if(jfc.showSaveDialog(JNotepadPP.this)!=JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(
							JNotepadPP.this, 
							"Ništa nije snimljeno.", 
							"Upozorenje", 
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				Path path;
				path = jfc.getSelectedFile().toPath();
				try {
					JNotepadPP.this.documentModel.saveDocument(JNotepadPP.this.documentModel.getCurrentDocument(),
							path);
				} catch(RuntimeException ex) {
					JOptionPane.showMessageDialog(JNotepadPP.this, ex.getMessage());
				}
			};
		};

		saveDocumentAction = new LocalizableAction("save", flp) {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				if(!JNotepadPP.this.documentModel.getCurrentDocument().isModified()) return;
				Path path; 
				if(JNotepadPP.this.documentModel.getCurrentDocument().getFilePath() != null)
					path = JNotepadPP.this.documentModel.getCurrentDocument().getFilePath();
				else {
					JFileChooser jfc = new JFileChooser();
					jfc.setDialogTitle("Save document");
					if(jfc.showSaveDialog(JNotepadPP.this)!=JFileChooser.APPROVE_OPTION) {
						JOptionPane.showMessageDialog(
								JNotepadPP.this, 
								"Ništa nije snimljeno.", 
								"Upozorenje", 
								JOptionPane.WARNING_MESSAGE);
						return;
					}
					path = jfc.getSelectedFile().toPath();
				}
				try {
					JNotepadPP.this.documentModel.saveDocument(JNotepadPP.this.documentModel.getCurrentDocument(),
							path);
				} catch (MultipleVersionsOfFileException ex) {
					JOptionPane.showMessageDialog(JNotepadPP.this, ex.getMessage());
				}
			};
		};

		statsAction = new LocalizableAction("stats", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();
				int length = textArea.getText().length();
				String text = textArea.getText();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				int numberOfNewLines = 0;
				int numberOfChars = 0;
				for(int i = 0; i < length; i++) {
					if(text.charAt(i) == '\n') {
						numberOfNewLines++;
					} else if(text.charAt(i) != '\n' &&
							text.charAt(i) != '\t' &&
							text.charAt(i) != ' '){
						numberOfChars++;
					}
				}

				String message = String.format("Your document has %d characters, %d non-blank characters and %d lines.", 
						length, numberOfChars, numberOfNewLines + 1);

				JOptionPane.showMessageDialog(JNotepadPP.this, message);

			}
		};

		copyAction = new LocalizableAction("copy", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				JNotepadPP.this.tempCash = textArea.getText().substring(start, end);
			}
		};

		cutAction = new LocalizableAction("cut", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				JNotepadPP.this.tempCash = textArea.getText().substring(start, end);
				String newString = textArea.getText().substring(0, start) 
						+ textArea.getText().substring(end);
				textArea.setText(newString);
			}
		};

		newDocumentAction = new LocalizableAction("new", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JNotepadPP.this.documentModel.createNewDocument();
				titleChanged();
			}
		};

		closeCurrentTabDocumentAction = new LocalizableAction("close", flp) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				if(JNotepadPP.this.documentModel.getCurrentDocument().isModified()) {
					Path path =  JNotepadPP.this.documentModel.getCurrentDocument().getFilePath();
					String name;
					if(path == null)
						name = "(unnamed)";
					else
						name = path.getFileName().toString();
					int response = JOptionPane.showOptionDialog(
							JNotepadPP.this, 
							"Do you wish to save the file "+ name + "?", 
							"Saving", 
							JOptionPane.YES_NO_OPTION, 
							JOptionPane.QUESTION_MESSAGE, 
							null, 
							null, 
							null);
					if(response == JOptionPane.YES_OPTION) {
						SingleDocumentModel currentDocument = JNotepadPP.this.documentModel.getCurrentDocument();
						if(currentDocument.getFilePath() == null) 
							saveAsDocumentAction.actionPerformed(e);
						else {
							JNotepadPP.this.documentModel.saveDocument(
									currentDocument,
									currentDocument.getFilePath());
						}
					}
				}
				JNotepadPP.this.documentModel.closeDocument(JNotepadPP.this.documentModel.getCurrentDocument());
				titleChanged();
			};
		};

		pasteAction = new LocalizableAction("paste", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				String pre = textArea.getText().substring(0, start);
				String post = textArea.getText().substring(end);

				String newString = pre
						+ JNotepadPP.this.tempCash
						+ post;
				textArea.setText(newString);
			}
		};

		exitAction = new LocalizableAction("exit", flp) {

			private static final long serialVersionUID = 1L;



			@Override
			public void actionPerformed(ActionEvent e) {

				int length = JNotepadPP.this.documentModel.getNumberOfDocuments();
				while(JNotepadPP.this.documentModel.getCurrentDocument() != null) {
					closeCurrentTabDocumentAction.actionPerformed(null); 
				}

				dispose();

				System.exit(0);
			}
		};

		changeCaseToUpperAction = new LocalizableAction("upper", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				String oldTempCash = tempCash;
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				if(start != end) {
					cutAction.actionPerformed(e);
					tempCash = tempCash.toUpperCase();
					textArea.getCaret().setDot(start);
					pasteAction.actionPerformed(e);

				}
				tempCash = oldTempCash;
			}
		};


		changeCaseToLowerAction = new LocalizableAction("lower", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				String oldTempCash = tempCash;
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				if(start != end) {
					cutAction.actionPerformed(e);
					tempCash = tempCash.toLowerCase();
					textArea.getCaret().setDot(start);
					pasteAction.actionPerformed(e);

				}
				tempCash = oldTempCash;
			}
		};

		invertCaseAction = new LocalizableAction("invert", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				String oldTempCash = tempCash;
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				if(start != end) {
					cutAction.actionPerformed(e);
					StringBuilder b = new StringBuilder();
					for(char c: tempCash.toCharArray()) {
						if(Character.isUpperCase(c))
							b.append(Character.toLowerCase(c));
						else 
							b.append(Character.toUpperCase(c));
					}
					tempCash = b.toString();

					textArea.getCaret().setDot(start);
					pasteAction.actionPerformed(e);

				}
				tempCash = oldTempCash;
			}
		};


		sortAscendingAction = new LocalizableAction("asc", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				Locale hrLocale = new Locale(flp.getLanguage());
				Collator collator = Collator.getInstance(hrLocale);
				
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();
				

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				String text = textArea.getText();
				int length = text.length();
				while(end < length && text.charAt(end) != '\n') {
					end++;
				}
				
				while(start > 0 && text.charAt(start) != '\n') {
					start--;
				}
				
				if(start != end) {
					String forSort = text.substring(start, end);
					
					StringBuilder b = new StringBuilder();
					
					String[] lines = forSort.split("\n");
					Arrays.sort(lines, collator);
					for(String s: lines) {
						b.append(s);
						b.append("\n");
					}
					
					String newText = text.substring(0, start) + b.substring(0, b.length() - 1) +  text.substring(end);
					textArea.setText(newText);
				}
			}
		};

		sortDescendingAction = new LocalizableAction("desc", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				Locale hrLocale = new Locale(flp.getLanguage());
				Collator collator = Collator.getInstance(hrLocale);
				
				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();
				

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				String text = textArea.getText();
				int length = text.length();
				while(end < length && text.charAt(end) != '\n') {
					end++;
				}
				
				while(start > 0 && text.charAt(start) != '\n') {
					start--;
				}
				
				if(start != end) {
					String forSort = text.substring(start, end);
					
					StringBuilder b = new StringBuilder();
					
					String[] lines = forSort.split("\n");
					Arrays.sort(lines, collator);
					for(String s: lines) {
						
						b.insert(0, s);
						b.insert(0, "\n");
						
					}
					
					String newText = text.substring(0, start) + b.substring(1) +  text.substring(end);
					textArea.setText(newText);
				}
			}
		};
		
		removeUniqueAction = new LocalizableAction("unique", flp) {

			/**
			 * default serialization
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				JTextArea textArea = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent();
				int start = textArea.getCaret().getDot();
				int end = textArea.getCaret().getMark();
				

				if(start > end) {
					int temp = end;
					end = start;
					start = temp;
				}

				String text = textArea.getText();
				int length = text.length();
				while(end < length && text.charAt(end) != '\n') {
					end++;
				}
				
				while(start > 0 && text.charAt(start) != '\n') {
					start--;
				}
				
				if(start != end) {
					String forSort = text.substring(start, end);
					
					StringBuilder b = new StringBuilder();
					
					String[] lines = forSort.split("\n");
					LinkedHashSet<String> set = new LinkedHashSet<>();
					for(String s: lines) {
						set.add(s);
					}
					for(String s: set) {
						b.append(s);
						b.append("\n");
					}
					String newText = text.substring(0, start) + b.substring(0, b.length()-1) +  text.substring(end);
					textArea.setText(newText);
				}
			
			}
		};


		initGUI();

	}
	
	/**
	 * Method which initializes GUI.
	 */
	
	private void initGUI() {
		Container panel = getContentPane();
		panel.setLayout(new BorderLayout());

		documentModel = new DefaultMultipleDocumentModel();
		toolbar = new JToolBar();
		statusBar = new JPanel(new BorderLayout());

		JPanel innerPanel = new JPanel(new BorderLayout());
		innerPanel.add(documentModel.getVisualComponent(), BorderLayout.CENTER);
		innerPanel.add(statusBar, BorderLayout.PAGE_END);
		createActions();
		createMenu();
		createToolbars();
		panel.add(innerPanel, BorderLayout.CENTER);
		Path pathForTitle = this.documentModel.getCurrentDocument().getFilePath();
		if(pathForTitle == null)
			setTitle("(unnamed) - JNotepad++");
		else setTitle(pathForTitle.toString() + " - JNotepad++");
		
		JPanel leftPanel = new JPanel(new BorderLayout());
		statusBar.add(leftPanel, BorderLayout.LINE_START);
		JLabel leftLabel = new JLabel();
		JLabel rightLabel = new JLabel();
		leftPanel.add(leftLabel, BorderLayout.LINE_START);
		leftPanel.add(new JSeparator(SwingConstants.VERTICAL));
		leftPanel.add(rightLabel, BorderLayout.LINE_END);
		JLabel clockLabel = new JLabel();
		statusBar.add(clockLabel, BorderLayout.LINE_END);
		
		leftLabel.setText(String.format("Length:0" + " ".repeat(22)));
		rightLabel.setText("Ln:0  Col:0  Sel:0");
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		String time = dtf.format(now);
		
		clockLabel.setText(time + "  ");
		

		Timer t = new Timer(1000, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				LocalDateTime now = LocalDateTime.now();  
				String time = dtf.format(now);
				clockLabel.setText(new String(time + "  "));

			}
		});
		t.start();

		this.documentModel.getCurrentDocument().getTextComponent().addCaretListener(new CaretListener() {

			@Override
			public void caretUpdate(CaretEvent e) {
				String text = JNotepadPP.this.documentModel.getCurrentDocument().getTextComponent().getText();
				int numberOfNewLines = 0;
				int charsInLine = 0;
				for(int i = 0; i < e.getDot(); i++) {
					if(text.charAt(i) == '\n') {
						numberOfNewLines++;
						charsInLine = 0;
					} else {
						charsInLine++;
					}
				}
				String length = String.format("length:%d", text.length());
				String ln = String.format("Ln:%d", numberOfNewLines + 1);
				String Col = String.format("Col:%d", charsInLine + 1);
				String Sel = String.format("Sel:%d", Math.abs(e.getDot() - e.getMark()));
				String right = ln + "  " + Col + "  " + Sel;
				

				leftLabel.setText(length + " ".repeat(30-length.length()));
				rightLabel.setText(right);

			}
		});
		

		this.documentModel.addMultipleDocumentListener(new MultipleDocumentListener() {

			@Override
			public void documentRemoved(SingleDocumentModel model) {
				// TODO Auto-generated method stub

			}

			@Override
			public void documentAdded(SingleDocumentModel model) {
				// TODO Auto-generated method stub

			}

			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				JNotepadPP.this.titleChanged();
			}
		});
	}

	/**
	 * Help-method which createss toolbars.
	 */
	private void createToolbars() {

		JToolBar toolBar = new JToolBar("Alati");
		toolBar.setFloatable(true);

		toolBar.add(new JButton(newDocumentAction));
		toolBar.add(new JButton(openDocumentAction));
		toolBar.add(new JButton(saveDocumentAction));
		toolBar.add(new JButton(saveAsDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(statsAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(closeCurrentTabDocumentAction));
		toolBar.add(new JButton(exitAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(copyAction));
		toolBar.add(new JButton(pasteAction));
		toolBar.add(new JButton(cutAction));


		this.getContentPane().add(toolBar, BorderLayout.PAGE_START);


	}
	
	/**
	 * Help-method which creates menu.
	 */

	private void createMenu() {
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu(flp.getString("file"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				fileMenu.setText(flp.getString("file"));

			}
		});
		menuBar.add(fileMenu);

		fileMenu.add(new JMenuItem(newDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(openDocumentAction));
		fileMenu.add(new JMenuItem(saveDocumentAction));
		fileMenu.add(new JMenuItem(saveAsDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(statsAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(closeCurrentTabDocumentAction));
		fileMenu.add(new JMenuItem(exitAction));


		JMenu editMenu = new JMenu(flp.getString("edit"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				editMenu.setText(flp.getString("edit"));

			}
		});

		editMenu.add(new JMenuItem(cutAction));
		editMenu.add(new JMenuItem(copyAction));
		editMenu.add(new JMenuItem(pasteAction));
		menuBar.add(editMenu);


		JMenu languagesMenu = new JMenu(flp.getString("languages"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				languagesMenu.setText(flp.getString("languages"));

			}
		});

		JMenuItem item1 = new JMenuItem(flp.getString("hrv"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				item1.setText(flp.getString("hrv"));

			}
		});

		languagesMenu.add(item1);
		item1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				LocalizationProvider.getInstance().setLanguage("hr");
			}
		});

		JMenuItem item2 = new JMenuItem(flp.getString("en"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				item2.setText(flp.getString("en"));
			}
		});

		languagesMenu.add(item2);
		item2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				LocalizationProvider.getInstance().setLanguage("en");

			}
		});

		JMenuItem item3 = new JMenuItem(flp.getString("ge"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				item3.setText(flp.getString("ge"));

			}
		});

		languagesMenu.add(item3);
		item3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				LocalizationProvider.getInstance().setLanguage("ge");

			}
		});
		menuBar.add(languagesMenu);

		JMenu toolsMenu = new JMenu(flp.getString("tools"));
		changeCaseToLowerAction.setEnabled(false);
		changeCaseToUpperAction.setEnabled(false);
		sortAscendingAction.setEnabled(false);
		sortDescendingAction.setEnabled(false);
		removeUniqueAction.setEnabled(false);
		invertCaseAction.setEnabled(false);
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				toolsMenu.setText(flp.getString("tools"));

			}
		});
		
		CaretListener caretListenerForEnablingTools = new CaretListener() {

			@Override
			public void caretUpdate(CaretEvent e) {
				if(e.getDot() == e.getMark()) {
					changeCaseToLowerAction.setEnabled(false);
					changeCaseToUpperAction.setEnabled(false);
					sortAscendingAction.setEnabled(false);
					sortDescendingAction.setEnabled(false);
					removeUniqueAction.setEnabled(false);
					invertCaseAction.setEnabled(false);
				} else {
					changeCaseToLowerAction.setEnabled(true);
					changeCaseToUpperAction.setEnabled(true);
					sortAscendingAction.setEnabled(true);
					sortDescendingAction.setEnabled(true);
					removeUniqueAction.setEnabled(true);
					invertCaseAction.setEnabled(true);
				}
			}
		};
		
		this.documentModel.addMultipleDocumentListener(new MultipleDocumentListener() {
			
			@Override
			public void documentRemoved(SingleDocumentModel model) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void documentAdded(SingleDocumentModel model) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				if(current != null) current.getTextComponent().removeCaretListener(caretListenerForEnablingTools);
				current = JNotepadPP.this.documentModel.getCurrentDocument();
				current.getTextComponent().addCaretListener(caretListenerForEnablingTools);
				
			}
		});
		
		
		JMenu toolsChange = new JMenu(flp.getString("changeCase"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				toolsChange.setText(flp.getString("changeCase"));

			}
		});
		toolsMenu.add(toolsChange);
		toolsChange.add(new JMenuItem(changeCaseToUpperAction));
		toolsChange.add(new JMenuItem(changeCaseToLowerAction));
		toolsChange.add(new JMenuItem(invertCaseAction));

		JMenu sort = new JMenu(flp.getString("sort"));
		flp.addLocalizationListener(new ILocalizationListener() {
			@Override
			public void localizationChanged() {
				sort.setText(flp.getString("sort"));
			}
		});
		toolsMenu.add(sort);
		sort.add(new JMenuItem(sortAscendingAction));
		sort.add(new JMenuItem(sortDescendingAction));
		
		toolsMenu.add(new JMenuItem(removeUniqueAction));
		
		menuBar.add(toolsMenu);

		this.setJMenuBar(menuBar);

	}
	
	/**
	 * Help method which creates actions.
	 */
	
	private void createActions() {
		openDocumentAction.putValue(
				Action.NAME, 
				flp.getString("open"));
		openDocumentAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control O")); 
		openDocumentAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_O); 
		openDocumentAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Used to open existing file from disk."); 

		saveDocumentAction.putValue(
				Action.NAME, 
				flp.getString("save"));
		saveDocumentAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control S")); 
		saveDocumentAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_S); 
		saveDocumentAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Used to save current file to disk.");

		saveAsDocumentAction.putValue(
				Action.NAME, 
				flp.getString("saveAs"));
		saveAsDocumentAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control shift S")); 
		saveAsDocumentAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_S); 
		saveAsDocumentAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Used to save new version of current file to disk."); 

		copyAction.putValue(
				Action.NAME, 
				flp.getString("copy"));
		copyAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control C")); 
		copyAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_C); 
		copyAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Used to copy selected text");

		cutAction.putValue(
				Action.NAME, 
				flp.getString("cut"));
		cutAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control shift C")); 
		cutAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_C); 
		cutAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Used to cut selected text"); 

		pasteAction.putValue(
				Action.NAME, 
				flp.getString("paste"));
		pasteAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control V")); 
		pasteAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_V); 
		pasteAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Used to paste text"); 


		exitAction.putValue(
				Action.NAME, 
				flp.getString("exit"));
		exitAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control X"));
		exitAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_X); 
		exitAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Exit application."); 

		newDocumentAction.putValue(
				Action.NAME, 
				flp.getString("new"));
		newDocumentAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control N"));
		newDocumentAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_N); 
		newDocumentAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Create new document.");

		closeCurrentTabDocumentAction.putValue(
				Action.NAME, 
				flp.getString("close"));
		closeCurrentTabDocumentAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control W"));
		closeCurrentTabDocumentAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_W); 
		closeCurrentTabDocumentAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Closes current tab.");

		statsAction.putValue(
				Action.NAME, 
				flp.getString("stats"));
		statsAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control alt S"));
		statsAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_S); 
		statsAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Shows stats.");

		changeCaseToUpperAction.putValue(
				Action.NAME, 
				flp.getString("upper"));
		changeCaseToUpperAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control alt U"));
		changeCaseToUpperAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_U); 
		changeCaseToUpperAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Changes selected text to upper-case version of it.");

		changeCaseToLowerAction.putValue(
				Action.NAME, 
				flp.getString("lower"));
		changeCaseToLowerAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control alt L"));
		changeCaseToLowerAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_L); 
		changeCaseToLowerAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Changes selected text to lower-case version of it.");  

		invertCaseAction.putValue(
				Action.NAME, 
				flp.getString("invert"));
		invertCaseAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control alt I"));
		invertCaseAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_L); 
		invertCaseAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Changes selected text to inverted-case version of it.");

		sortAscendingAction.putValue(
				Action.NAME, 
				flp.getString("asc"));
		sortAscendingAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control alt E"));
		sortAscendingAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Sorts the selected text in ascending order."); 

		sortDescendingAction.putValue(
				Action.NAME, 
				flp.getString("desc"));
		sortDescendingAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control alt R"));
		sortDescendingAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Sorts the selected text in descending order.");
		
		removeUniqueAction.putValue(
				Action.NAME, 
				flp.getString("unique"));
		removeUniqueAction.putValue(
				Action.ACCELERATOR_KEY, 
				KeyStroke.getKeyStroke("control shift U"));
		removeUniqueAction.putValue(
				Action.MNEMONIC_KEY, 
				KeyEvent.VK_U); 
		removeUniqueAction.putValue(
				Action.SHORT_DESCRIPTION, 
				"Removes all selected lines which are duplicated, except for the first one."); 
		
	}
	
	/**
	 * Main function
	 * @param args not important
	 */
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				LocalizationProvider.getInstance().setLanguage("en");
				JNotepadPP prozor = new JNotepadPP();
				prozor.setVisible(true);
			}
		});
	}

	/**
	 * Method invoked when title needs to be changed.
	 */

	private void titleChanged() {
		SingleDocumentModel current = JNotepadPP.this.documentModel.getCurrentDocument();
		String name = null;
		if(current != null) {
			Path path = JNotepadPP.this.documentModel.getCurrentDocument().getFilePath();
			if(path != null)
				name = path.toString();
			else
				name = "(unnamed)";
		} else {

		}
		JNotepadPP.this.setTitle(name + " - JNotepad++");
	}





}
