package hr.fer.oprpp1.hw08.jnotepadpp;

import java.nio.file.Path;

import javax.swing.JComponent;

/**
 * Interface which represents a model of the notepad text area. It consists of
 * multiple SingleDocumentModels. 
 * @author muham
 *
 */

public interface MultipleDocumentModel extends Iterable<SingleDocumentModel> {
	/**
	 * returns the graphical component which is responsible for displaying 
	 * the entire MultipleDocumentModel's user interface
	 * @return  the graphical component which is responsible for displaying 
	 * the entire MultipleDocumentModel‘s user interface
	 */
	JComponent getVisualComponent();
	
	/**
	 * creates a new blank document represented by SingleDocumentModel
	 * @return
	 */
	
	SingleDocumentModel createNewDocument();
	
	/**
	 * Returns current document.
	 * @return current document
	 */
	
	SingleDocumentModel getCurrentDocument();
	
	/**
	 * Loads a document from the disc, from the specified path.
	 * @param path path of the document that needs to be loaded.
	 * @return path of the document that needs to be loaded
	 */
	
	SingleDocumentModel loadDocument(Path path);
	
	/**
	 *
	 * Saves the document represented by specified SingleDocumentModel.
	 * @param model the model to be saved
	 * @param newPath path at which this model needs to be saved to. 
	 */
	
	void saveDocument(SingleDocumentModel model, Path newPath);
	
	/**
	 * Closes the document represented by specified SingleDocumentModel.
	 * @param model the model to be closed
	 */
	
	void closeDocument(SingleDocumentModel model);
	
	/**
	 * Adds the provided MultipleDocumentListener to the list of all MultipleDocumentListener
	 * which are subscribed to this MultipleDocumentModel.
	 * @param l MultipleDocumentListener that needs to be added to the list of all MultipleDocumentListener
	 * who are subscribed to this MultipleDocumentModel.
	 */
	
	void addMultipleDocumentListener(MultipleDocumentListener l);
	
	/**
	 * Removes the provided MultipleDocumentListener from the list of all MultipleDocumentListener
	 * which are subscribed to this MultipleDocumentModel.
	 * @param l MultipleDocumentListener that needs to be removed from the list of all MultipleDocumentListener
	 * who are subscribed to this MultipleDocumentModel.
	 */
	
	void removeMultipleDocumentListener(MultipleDocumentListener l);
	
	/**
	 * Returns the number of SingleDocumentModels present in the MultipleDocumentModel.
	 * @return
	 */
	
	int getNumberOfDocuments();
	
	/**
	 * Returns SingleDocumentModel which is at the provided index.
	 * @param index index of the SingleDocumentModel to be returned
	 * @return SingleDocumentModel which is at the provided index
	 */
	
	SingleDocumentModel getDocument(int index);
	
	/**
	 * Returns SingleDocumentModel which references the provided path. If such model
	 * doesn't exist, null is returned.
	 * @param path path to the document whose SingleDocumentModel representation is requested
	 * @return SingleDocumentModel which references the provided path. If such model
	 * doesn't exist, null is returned.
	 */
	
	SingleDocumentModel findForPath(Path path); //null, if no such model exists
	
	/**
	 * Returns the index of the provided SingleDocumentModel. If such model
	 * is not present, -1 is returned.
	 * @param doc SingleDocumentModel whose index is requested
	 * @return index of the requested SingleDocumentModel, -1 if such model
	 * is not present
	 */
	int getIndexOfDocument(SingleDocumentModel doc); //-1 if not present
}