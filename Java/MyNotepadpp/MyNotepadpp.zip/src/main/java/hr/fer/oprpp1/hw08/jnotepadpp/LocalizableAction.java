package hr.fer.oprpp1.hw08.jnotepadpp;




import javax.swing.AbstractAction;

/**
 * Class which represents a localizable action.
 * @author muham
 *
 */

public abstract class LocalizableAction extends AbstractAction{
	private static final long serialVersionUID = 1L;		
	private String key;
	
	public LocalizableAction(String key, ILocalizationProvider lp) {
		this.key = key;
		putValue(NAME, lp.getString(key));
		lp.addLocalizationListener(new ILocalizationListener() {
			
			@Override
			public void localizationChanged() {
				putValue(NAME, lp.getString(LocalizableAction.this.key));
			}
		});
	}

}
