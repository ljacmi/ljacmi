package hr.fer.oprpp1.hw08.jnotepadpp;

/**
 * Exception thrown when JNotepaddPP is trying to save a file which has multiple versions opened.
 * @author muham
 *
 */
public class MultipleVersionsOfFileException extends RuntimeException{

	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Public constructor which takes exactly one argument, string which 
	 * describes the exception.
	 * @param ex
	 */
	public MultipleVersionsOfFileException(String ex) {
		super(ex);
	}

}
