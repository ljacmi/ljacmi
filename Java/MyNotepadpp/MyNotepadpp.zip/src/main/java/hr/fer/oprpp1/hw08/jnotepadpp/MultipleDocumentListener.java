package hr.fer.oprpp1.hw08.jnotepadpp;

/**
 * Interface which represents a listener of the MultipleDocumentModel.
 * @author muham
 *
 */

public interface MultipleDocumentListener {
	
	/**
	 * Method invoked when current document has been changed. Either model provided
	 * as argument can be null, but both can't be null at the same time.
	 * @param previousModel model that has been marked as current until now
	 * @param currentModel new current model
	 */
	
	void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel);
	
	/**
	 * Method invoked when new document has been added.
	 * @param model document whose addition has triggered this method
	 */
	
	void documentAdded(SingleDocumentModel model);
	
	/**
	 * Method invoked when provided document has been removed.
	 * @param model document whose removal has triggered this method
	 */
	
	void documentRemoved(SingleDocumentModel model);
}