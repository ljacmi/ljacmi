package hr.fer.oprpp1.hw08.jnotepadpp;

/**
 * Interface which represents a listener of the SingleDocumentModel.
 * @author muham
 *
 */

public interface SingleDocumentListener {
	/**
	 * Method invoked when modify-status of the provided SingleDocumentModel has been changed.
	 * @param model whose change of the modify-status caused invocation of this method
	 */
	void documentModifyStatusUpdated(SingleDocumentModel model);
	
	/**
	 * Method invoked when path of the provided SingleDocumentModel has been changed.
	 * @param model whose change of the path caused invocation of this method
	 */
	
	void documentFilePathUpdated(SingleDocumentModel model);
}