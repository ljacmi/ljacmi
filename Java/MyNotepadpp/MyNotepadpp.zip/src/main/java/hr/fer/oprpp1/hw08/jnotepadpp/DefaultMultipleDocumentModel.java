package hr.fer.oprpp1.hw08.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Calss which represents default implementation of MultipleDocumentModel.
 * @author muham
 *
 */
public class DefaultMultipleDocumentModel extends JTabbedPane implements MultipleDocumentModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Keeps references to all singleDocumnetModels which this MultipleDocumentModel consists of
	 */
	private List<SingleDocumentModel> singleDocuments = new LinkedList<>();

	/**
	 * Keeps reference to SingleDocument model currently in use
	 */

	private SingleDocumentModel current;

	/**
	 * List of all multipleDocumentListeners.
	 */

	private List<MultipleDocumentListener> multipleDocumentListeners;

	/**
	 * Constructor
	 */


	public DefaultMultipleDocumentModel() {
		MultipleDocumentListener listener = new MultipleDocumentListener() {

			@Override
			public void documentRemoved(SingleDocumentModel model) {
				int index = DefaultMultipleDocumentModel.this.singleDocuments.indexOf(model);
				DefaultMultipleDocumentModel.this.singleDocuments.remove(model);
				DefaultMultipleDocumentModel.this.removeTabAt(index);

			}

			@Override
			public void documentAdded(SingleDocumentModel model) {
				String name; 
				if(model.getFilePath() == null)
					name = "(unnamed)";
				else 
					name = model.getFilePath().getFileName().toString();

				JPanel panel = new JPanel(new BorderLayout());
				panel.add(new JScrollPane(model.getTextComponent(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));

				DefaultMultipleDocumentModel.this.addTab(name, panel);

				model.getTextComponent().addKeyListener(new KeyListener() {

					@Override
					public void keyTyped(KeyEvent e) {


						model.setModified(true);

						for(MultipleDocumentListener l: DefaultMultipleDocumentModel.this.multipleDocumentListeners) {
							l.currentDocumentChanged(model, model);
						}
					}

					@Override
					public void keyReleased(KeyEvent e) {
					}

					@Override
					public void keyPressed(KeyEvent e) {
					}
				});

				model.setModified(false);
				for(MultipleDocumentListener l: DefaultMultipleDocumentModel.this.multipleDocumentListeners) {
					l.currentDocumentChanged(DefaultMultipleDocumentModel.this.getCurrentDocument(), model);
				}

			}

			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				int index = singleDocuments.indexOf(currentModel);
				if(index > -1) {
					try {
						DefaultMultipleDocumentModel.this.setSelectedIndex(index);

						if(currentModel.getFilePath()!= null) 
							DefaultMultipleDocumentModel.this.setToolTipTextAt(index, currentModel.getFilePath().toString());
						InputStream is;
						if(currentModel.isModified())
							is = this.getClass().getResourceAsStream("icons/redFloppyDisc.png");
						else 
							is = this.getClass().getResourceAsStream("icons/greenFloppyDisc.png");
						if(is==null) throw new RuntimeException("Icon can't be loaded!");
						byte[] bytes;
						try {
							bytes = is.readAllBytes();
							is.close();
							ImageIcon icon = new ImageIcon(bytes);
							icon = rescaleIcon(icon);
							DefaultMultipleDocumentModel.this.setIconAt(index, icon);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} catch(Exception e){
						//do nothing
					}

				}
			}
		};
		this.multipleDocumentListeners = new LinkedList<>();
		this.addMultipleDocumentListener(listener);

		//da odredim current
		this.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				int index = DefaultMultipleDocumentModel.this.getSelectedIndex();
				SingleDocumentModel old = DefaultMultipleDocumentModel.this.current;
				if(index >= 0)
					DefaultMultipleDocumentModel.this.current = 
					DefaultMultipleDocumentModel.this.singleDocuments.get(index);
				for(MultipleDocumentListener l: DefaultMultipleDocumentModel.this.multipleDocumentListeners) {
					l.currentDocumentChanged(old, current);
				}
			}
		});

		this.createNewDocument();

	}

	@Override
	public SingleDocumentModel loadDocument(Path path) {
		byte[] okteti;
		try {
			okteti = Files.readAllBytes(path);
		} catch(Exception ex) {
			JOptionPane.showMessageDialog(
					this, 
					"Pogreška prilikom čitanja datoteke "+path+".", 
					"Pogreška", 
					JOptionPane.ERROR_MESSAGE);
			return null;
		}
		String tekst = new String(okteti, StandardCharsets.UTF_8);

		DefaultSingleDocumentModel newDocumentModel = new DefaultSingleDocumentModel(path, tekst);
		DefaultMultipleDocumentModel.this.singleDocuments.add(newDocumentModel);
		for(MultipleDocumentListener l: this.multipleDocumentListeners) {
			l.documentAdded(newDocumentModel);
		}
		this.current = newDocumentModel;

		return newDocumentModel;
	}

	@Override
	public Iterator<SingleDocumentModel> iterator() {
		return this.singleDocuments.iterator();
	}

	@Override
	public JComponent getVisualComponent() {
		return this;
	}

	@Override
	public SingleDocumentModel createNewDocument() {
		DefaultSingleDocumentModel newDocumentModel = new DefaultSingleDocumentModel(null, null);
		this.singleDocuments.add(newDocumentModel);
		for(MultipleDocumentListener l: this.multipleDocumentListeners) {
			l.documentAdded(newDocumentModel);
		}
		this.current = newDocumentModel;
		return newDocumentModel;
	}

	@Override
	public SingleDocumentModel getCurrentDocument() {
		return this.current;
	}

	@Override
	public void saveDocument(SingleDocumentModel model, Path newPath) {

		if(newPath == null) {
			if(model.getFilePath() != null) {
				newPath = model.getFilePath();
			} else {
				//cant do anything
				return;
			}
		}

		if(newPath.toFile().exists()) {

			for(SingleDocumentModel m: DefaultMultipleDocumentModel.this.singleDocuments) {
				if(!m.equals(model) && m.getFilePath() != null && m.getFilePath().equals(newPath)) {
					throw new MultipleVersionsOfFileException("File with such path is already opened!");
				}
			}

			int response = JOptionPane.showOptionDialog(this, "Do you wish to overwrite?", "Saving", 
					JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE, 
					null, 
					null, 
					null);
			if(response == JOptionPane.YES_OPTION) {
				try {
					Files.write(newPath, model.getTextComponent().getText().getBytes());
				} catch (IOException e) {
					e.printStackTrace();
				}
				model.setModified(false);
			} else if(response == JOptionPane.NO_OPTION){
				//do nothing
			}
		} else {
			try {
				Files.write(newPath, model.getTextComponent().getText().getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			model.setModified(false);

		}
		model.setFilePath(newPath);

		int index = this.getIndexOfDocument(this.getCurrentDocument());
		this.removeTabAt(index);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(new JScrollPane(model.getTextComponent(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		this.insertTab(newPath.getFileName().toString(), null, panel, null, index);
		for(MultipleDocumentListener l: this.multipleDocumentListeners) {
			l.currentDocumentChanged(model, model);
		}

	}

	@Override
	public void closeDocument(SingleDocumentModel model) {
		for(MultipleDocumentListener l: this.multipleDocumentListeners) {
			l.documentRemoved(model);
		}
		if(DefaultMultipleDocumentModel.this.singleDocuments.size() > 0) {
			int index = DefaultMultipleDocumentModel.this.getSelectedIndex();
			DefaultMultipleDocumentModel.this.current = 
					DefaultMultipleDocumentModel.this.singleDocuments.get(index);
		}
		else 
			DefaultMultipleDocumentModel.this.current = null;

	}

	@Override
	public void addMultipleDocumentListener(MultipleDocumentListener l) {
		this.multipleDocumentListeners.add(l);

	}

	@Override
	public void removeMultipleDocumentListener(MultipleDocumentListener l) {
		this.multipleDocumentListeners.remove(l);

	}

	@Override
	public int getNumberOfDocuments() {
		return this.singleDocuments.size();
	}

	@Override
	public SingleDocumentModel getDocument(int index) {
		return this.singleDocuments.get(index);
	}

	/**
	 * @throws NullPointerException if provided path is null
	 */

	@Override
	public SingleDocumentModel findForPath(Path path) {

		if(path == null) throw new NullPointerException();

		for(SingleDocumentModel model: this.singleDocuments) {
			if(model.getFilePath().equals(path)) {
				return model;
			}
		}
		return null;
	}

	@Override
	public int getIndexOfDocument(SingleDocumentModel doc) {
		int length = this.singleDocuments.size();
		for(int i = 0; i < length; i++) {
			SingleDocumentModel model = this.singleDocuments.get(i);
			if(model.equals(doc)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Help-method used for rescaling icons.
	 * @param icon Image that needs to be rescaled to the icon size.
	 * @return rescaled icon
	 */

	private ImageIcon rescaleIcon(ImageIcon icon) {
		Image image = icon.getImage();  
		Image newimg = image.getScaledInstance(12, 12, java.awt.Image.SCALE_SMOOTH);  
		icon = new ImageIcon(newimg);  
		return icon;
	}
}
