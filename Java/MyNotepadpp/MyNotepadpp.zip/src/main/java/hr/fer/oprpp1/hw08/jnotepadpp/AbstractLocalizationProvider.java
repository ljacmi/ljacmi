package hr.fer.oprpp1.hw08.jnotepadpp;

import java.util.LinkedList;
import java.util.List;

/**
 * Class which represents a AbstractLocalizationProvider.
 * @author muham
 *
 */

public abstract class AbstractLocalizationProvider implements ILocalizationProvider{
	
	/**
	 * Keeps reference to all listeners of this ILocalizationProvider.
	 */
	private List<ILocalizationListener> allListeners;
	
	/**
	 * Constructor
	 */
	
	public AbstractLocalizationProvider() {
		this.allListeners = new LinkedList<>();
	}
	
	@Override
	public void addLocalizationListener(ILocalizationListener listener) {
		allListeners.add(listener);
		
	}
	
	@Override
	public void removeLocalizationListener(ILocalizationListener listener) {
		allListeners.remove(listener);
		
	}
	
	/**
	 * Notifies all listeners.
	 */
	
	public void fire() {
		for(ILocalizationListener l: allListeners) {
			l.localizationChanged();
		}
	}
	
	
}
