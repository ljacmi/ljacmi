package hr.fer.oprpp1.hw08.jnotepadpp;

import java.nio.file.Path;

import javax.swing.JTextArea;




public interface SingleDocumentModel {
	
	/**
	 * Returns JTextArea which is used as edit space of the loaded document.
	 * @return JTextArea which is used as edit space of the loaded document
	 */
	
	JTextArea getTextComponent();
	
	/**
	 * Returns the path of the document represented by this SingleDocumentModel.
	 * @return path of the document represented by this SingleDocumentModel
	 */
	
	Path getFilePath();
	
	/**
	 * Sets the path to which this SingleDocumentModel points.
	 * @param path path to which this SingleDocumentModel points
	 */
	
	void setFilePath(Path path);
	
	/**
	 * Returns true if this SingleDocumentModel has been modified, false otherwise.
	 * @return true if this SingleDocumentModel has been modified, false otherwise
	 */
	
	boolean isModified();
	
	/**
	 * Sets the value of the modified variable to the provided value.
	 * @param modified value that the modified variable has to take
	 */
	
	void setModified(boolean modified);
	
	/**
	 * Adds the SingleDocumentListener to the list of all SingleDocumentListeners which listen
	 * to this SingleDocumentModel
	 * @param l SingleDocumentListener that needs to be added to the list of all SingleDocumentListeners 
	 * which listen to this SingleDocumentMode
	 */
	
	void addSingleDocumentListener(SingleDocumentListener l);
	
	/**
	 * Removes the SingleDocumentListener from the list of all SingleDocumentListeners which listen
	 * to this SingleDocumentModel
	 * @param l SingleDocumentListener that needs to be removed from the list of all SingleDocumentListeners 
	 * which listen to this SingleDocumentMode
	 */
	
	void removeSingleDocumentListener(SingleDocumentListener l);
}