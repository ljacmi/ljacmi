package hr.fer.oprpp1.hw08.jnotepadpp;

import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JTextArea;
/**
 * Class whicg represents default implementation of SingleDocumentModel.
 * @author muham
 *
 */
public class DefaultSingleDocumentModel implements SingleDocumentModel{
	/**
	 * Path of the document on the disc represented by this SingleDocumentModel.
	 */
	private Path path;
	
	/**
	 * Flag which keeps information about modification of this SingleDocumentModel.
	 */
	
	private boolean modificationStatus;
	
	/**
	 * reference to Swing component which is used for editing
	 */
	
	private JTextArea editArea;
	
	/**
	 * List which keeps references to all SingleDocumentListeners which listen to
	 * this 
	 */
	
	private List<SingleDocumentListener> listeners;
	

	
	public DefaultSingleDocumentModel(Path path, String content) {
		this.path = path;
		this.editArea = new JTextArea(content);
		this.listeners = new LinkedList<>();
		SingleDocumentListener listener = new SingleDocumentListener() {
			
			@Override
			public void documentModifyStatusUpdated(SingleDocumentModel model) {
				
				
			}
			
			@Override
			public void documentFilePathUpdated(SingleDocumentModel model) {
				//krivo
				DefaultSingleDocumentModel.this.setFilePath(path);
				
			}
		};
		
		this.addSingleDocumentListener(listener);
		
	}

	@Override
	public JTextArea getTextComponent() {
		return this.editArea;
	}

	@Override
	public Path getFilePath() {
		return this.path;
	}

	@Override
	public void setFilePath(Path path) {
		this.path = path;
		
	}

	@Override
	public boolean isModified() {
		return modificationStatus;
	}

	@Override
	public void setModified(boolean modified) {
		this.modificationStatus = modified;
		
	}

	@Override
	public void addSingleDocumentListener(SingleDocumentListener l) {
		listeners.add(l);
	}

	@Override
	public void removeSingleDocumentListener(SingleDocumentListener l) {
		listeners.remove(l);
	}
}
