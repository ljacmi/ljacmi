package hr.fer.oprpp1.hw08.jnotepadpp;

import javax.swing.JLabel;

/**
 * Class which represents a localized label.
 * @author muham
 *
 */
public class LJLabel extends JLabel{
	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 0;
	
	/**
	 * key
	 */
	
	private String key;
	
	/**
	 * Localization provider
	 */
	private ILocalizationProvider lp;
	
	/**
	 * Constructor
	 * @param key key
	 * @param lp LocalizationProvider
	 */
	
	public LJLabel(String key, ILocalizationProvider lp) {
		this.key = key;
		this.lp = lp;
		updateLabel();
		lp.addLocalizationListener(new ILocalizationListener() {
			
			@Override
			public void localizationChanged() {
				updateLabel();
			}
		});
	}
	
	/**
	 * Help-method used for updating text of the label.
	 */
	
	private void updateLabel() {
		setText(lp.getString(key));
	}
}
