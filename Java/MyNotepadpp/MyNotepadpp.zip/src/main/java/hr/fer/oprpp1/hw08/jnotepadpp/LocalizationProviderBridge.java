package hr.fer.oprpp1.hw08.jnotepadpp;

/**
 * Bridge design pattern which is used for connecting and disconnecting listeners from JFrame.
 * @author muham
 *
 */

public class LocalizationProviderBridge extends AbstractLocalizationProvider{
	/**
	 * flag which keeps track of whether or not bridge is currently connected
	 */
	private boolean connected;
	
	/**
	 * current language used by localization processes
	 */
	
	private String currentLanguage;
	
	/**
	 * decorated provider
	 */
	
	private ILocalizationProvider decoratedProvider;
	
	/**
	 * localization listener
	 */
	
	private ILocalizationListener listener;
	
	/**
	 * Constructor which takes some decoratedProvider.
	 * @param decoratedProvider decorated provider
	 */
	
	public LocalizationProviderBridge(ILocalizationProvider decoratedProvider) {
		this.decoratedProvider = decoratedProvider;
	}

	
	/**
	 * disconnect bridge
	 */
	public void disconnect() {
		this.decoratedProvider.removeLocalizationListener(listener);
	}

	/**
	 * connect bridge
	 */
	public void connect() {
		if(connected) {

		} else {
			this.connected = true;
			this.listener = new ILocalizationListener() {

				@Override
				public void localizationChanged() {
					currentLanguage = LocalizationProviderBridge.this.decoratedProvider.getLanguage();
					LocalizationProviderBridge.this.fire();

				}
			};
			this.decoratedProvider.addLocalizationListener(listener);
			if(!decoratedProvider.getLanguage().equals(currentLanguage)) {
				currentLanguage = decoratedProvider.getLanguage();
				listener.localizationChanged();
			}

		}
	}

	@Override
	public String getString(String key) {
		return decoratedProvider.getString(key);
	}

	@Override
	public String getLanguage() {
		return currentLanguage;
	}
}
