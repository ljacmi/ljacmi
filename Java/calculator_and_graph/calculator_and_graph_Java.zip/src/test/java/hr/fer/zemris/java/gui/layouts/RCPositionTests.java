package hr.fer.zemris.java.gui.layouts;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;

import org.junit.jupiter.api.Test;

public class RCPositionTests {
	
	@Test
	public void testParse() {
		RCPosition.parse("4, 7");
	}
	
	@Test
	public void testParseRowToSmall() {
		assertThrows(CalcLayoutException.class, () -> RCPosition.parse("0, 7"));
	}
	
	@Test
	public void testParseRowToBig() {
		assertThrows(CalcLayoutException.class, () -> RCPosition.parse("6, 7"));
	}
	
	@Test
	public void testParseColumnToBig() {
		assertThrows(CalcLayoutException.class, () -> RCPosition.parse("3, 8"));
	}
	
	@Test
	public void testParseColumnToSmall() {
		assertThrows(CalcLayoutException.class, () -> RCPosition.parse("3, 0"));
	}
	
	@Test
	public void testParseNotAllowedInRowOne() {
		assertThrows(CalcLayoutException.class, () -> RCPosition.parse("1, 3"));
	}
	
	@Test
	public void testParseMultipleSame() {
		CalcLayout layout = new CalcLayout();
		layout.addLayoutComponent(new JLabel("1"), RCPosition.parse("3, 7"));
		
		assertThrows(CalcLayoutException.class, () -> 
		layout.addLayoutComponent(new JLabel("2"), RCPosition.parse("3, 7")));
	}
	
	@Test
	public void test() {
		JPanel p = new JPanel(new CalcLayout(2));
		JLabel l1 = new JLabel(""); l1.setPreferredSize(new Dimension(10,30));
		JLabel l2 = new JLabel(""); l2.setPreferredSize(new Dimension(20,15));
		p.add(l1, new RCPosition(2,2));
		p.add(l2, new RCPosition(3,3));
		Dimension dim = p.getPreferredSize();
		assertEquals(152, dim.width);
		assertEquals(158, dim.height);
	}
	
	@Test
	public void test2() {
		JPanel p = new JPanel(new CalcLayout(2));
		JLabel l1 = new JLabel(""); l1.setPreferredSize(new Dimension(108,15));
		JLabel l2 = new JLabel(""); l2.setPreferredSize(new Dimension(16,30));
		p.add(l1, new RCPosition(1,1));
		p.add(l2, new RCPosition(3,3));
		Dimension dim = p.getPreferredSize();
		assertEquals(152, dim.width);
		assertEquals(158, dim.height);
	}
	
	
	
	
}
