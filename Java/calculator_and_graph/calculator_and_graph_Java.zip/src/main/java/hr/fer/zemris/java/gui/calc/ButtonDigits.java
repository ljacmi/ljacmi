package hr.fer.zemris.java.gui.calc;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import hr.fer.zemris.java.gui.calc.model.CalcModel;

/**
 * Button used in CalcModel for inputing digits. 
 * @author muham
 *
 */

public class ButtonDigits extends CalculatorButton{


	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor which creates a button for the given digit. 
	 * @param text text written on the button
	 * @param model reference to the CalcModel
	 * @param digit digit which the button is created for
	 */
	public ButtonDigits(String text, CalcModel model, Calculator c, int digit) {
		super(text, model);
		this.setFont(this.getFont().deriveFont(30f));
		
		addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!model.isEditable()) model.clear();
				model.insertDigit(digit);
			}
		});
	}
}
