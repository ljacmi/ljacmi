package hr.fer.zemris.java.gui.charts;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;


/**
 * Class which draws a BarChart specified by some file(which needs to be
 * in specific form, defined in the seventh homework).
 * @author muham
 *
 */

public class BarChartDemo extends JFrame{

	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * reference on the model of the BarChart
	 */
	private static BarChart chart;
	
	
	
	/**
	 * constructor for BarChartDemo
	 */
	
	public BarChartDemo() {
		super();
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("Prozor1");
		setLocation(20, 20);
		setSize(600, 600);
		initGUI();
		

	}
	
	/**
	 * method used for initializing GUI
	 */

	private void initGUI() {

		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		cp.add(new BarChartComponent(chart), BorderLayout.CENTER);
		
	}

	/**
	 * Component placed in the main frame which is used for drawing BarChart.
	 * @author muham
	 *
	 */

	
	
	/**
	 * Main function. It loads a file which defines a BarChart that needs to be drawn.
	 * @param args arguments, not important
	 */
	public static void main(String[] args) {
		Path path = Paths.get("primjerChart.txt");
		try(BufferedReader br = new BufferedReader(new InputStreamReader(new BufferedInputStream(Files.newInputStream(path))))){

			String[] lines = new String[6];

			for(int i = 0; i < 6; i++) {
				String line = br.readLine();
				if(line == null) {
					System.out.println("Format of the file is invalid!");
					return;
				}
				lines[i] = line;
			}

			List<XYValue> listOfValues = new ArrayList<>();
			String[] values = lines[2].split("\\s+");
			for(String value: values) {
				String[] xAndY = value.split(",");
				try {
					XYValue val = new XYValue(Integer.parseInt(xAndY[0]), Integer.parseInt(xAndY[1]));
					listOfValues.add(val);
				} catch(NumberFormatException e) {
					System.out.println("Format of the file is invalid!");
					return;
				}

			}
			int yMin, yMax, distanceBetweenTwoY;
			try {
				yMin = Integer.parseInt(lines[3]);
				yMax = Integer.parseInt(lines[4]);
				distanceBetweenTwoY = Integer.parseInt(lines[5]);
			} catch(NumberFormatException e) {
				System.out.println("Format of the file is invalid!");
				return;
			}

			chart = new BarChart(listOfValues, lines[0], lines[1], yMin, yMax, distanceBetweenTwoY);
			


		} catch (IOException e) {
			System.out.println("Cannot open specified file!");
		} 

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new BarChartDemo().setVisible(true);
			}
		});
	}
}
