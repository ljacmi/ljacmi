package hr.fer.zemris.java.gui.calc;

import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleUnaryOperator;

/**
 * Class which contains many constants which are operations that CalcModel can 
 * conduct.
 * @author muham
 *
 */
public class Operations {
	/**
	 * Binary operation of addition.
	 */
	public static final DoubleBinaryOperator ADDITION = (x, y) -> x + y;
	/**
	 * Binary operation of subtraction
	 */
	public static final DoubleBinaryOperator SUBTRACTION = (x, y) -> x - y;
	/**
	 * Binary operation of multiplication
	 */
	public static final DoubleBinaryOperator MULTIPLICATION = (x, y) -> x * y;
	/**
	 * Binary operation of division
	 */
	public static final DoubleBinaryOperator DIVISION = (x, y) -> x / y;
	/**
	 * Binary operation of potentiation.
	 */
	public static final DoubleBinaryOperator POW = (x, y) -> Math.pow(x, y);
	/**
	 * Binary operation of rooting.
	 */
	public static final DoubleBinaryOperator ROOT = (x, y) -> Math.pow(x, 1/y);
	
	
	
	/**
	 * Unary operation of taking a reciprocal value.
	 */
	public static final DoubleUnaryOperator RECIPROCAL = x -> 1/x;
	/**
	 * Unary operation of determining a sine of the value.
	 */
	public static final DoubleUnaryOperator SINE = x -> Math.sin(x);
	/**
	 * Unary operation of determining a cosine of the value.
	 */
	public static final DoubleUnaryOperator COSINE = x -> Math.cos(x);
	/**
	 * Unary operation of determining a tangent of the value.
	 */
	public static final DoubleUnaryOperator TANGENT = x -> Math.tan(x);
	/**
	 * Unary operation of determining a cotangent of the value.
	 */
	public static final DoubleUnaryOperator COTANGENT = x -> 1/Math.tan(x);
	/**
	 * Unary operation of determining a arcus sine of the value.
	 */
	public static final DoubleUnaryOperator ARCSIN = x -> Math.asin(x);
	
	/**
	 * Unary operation of determining a arcus cosine  of the value.
	 */
	
	public static final DoubleUnaryOperator ARCCOS = x -> Math.acos(x);
	
	/**
	 * Unary operation of determining a arcus tangent of the value.
	 */
	public static final DoubleUnaryOperator ARCTAN = x -> Math.atan(x);
	/**
	 * Unary operation of determining a arcus cotangent of the value.
	 */
	public static final DoubleUnaryOperator ARCCTG = x -> 1/Math.tan(x);
	
	/**
	 * Unary operation of determining logarithm of base 10 of the value.
	 */
	public static final DoubleUnaryOperator LOG_10 = x -> Math.log10(x);
	/**
	 * Unary operation of determining natural logarithm of the value.
	 */
	public static final DoubleUnaryOperator LOG_E = x -> Math.log(x);
	/**
	 * Unary operation of taking 10 to the power of value.
	 */
	public static final DoubleUnaryOperator POW_10 = x -> Math.pow(10, x);
	/**
	 * Unary operation of taking e to the power of value.
	 */
	public static final DoubleUnaryOperator POW_E = x -> Math.pow(Math.E, x);
}
