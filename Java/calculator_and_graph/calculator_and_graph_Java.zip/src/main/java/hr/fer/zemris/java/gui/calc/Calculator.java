package hr.fer.zemris.java.gui.calc;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.DoubleBinaryOperator;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalcValueListener;
import hr.fer.zemris.java.gui.layouts.CalcLayout;
import hr.fer.zemris.java.gui.layouts.RCPosition;

/**
 * Class which is used to create GUI for CalcModelImpl.
 * @author muham
 *
 */
public class Calculator extends JFrame{
	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * reference to CalcModel
	 */
	private CalcModel model;

	/**
	 * Represents a stack used by calculator. If some operand is missing, calculator first
	 * checks this stack and if it is not empty, then it uses its last value as operand. If
	 * it is empty, calculator will use 0. 
	 */

	protected List<Double> stack = new LinkedList<>();

	/**
	 * default constructor
	 */
	
	

	public Calculator() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		initGUI();
		setTitle("Calculator");
		setLocation(200, 200);
		setSize(500, 200);
		pack();
	}

	/**
	 * This method initializes GUI.
	 */

	private void initGUI() {
		Container cp = getContentPane();
		cp.setLayout(new CalcLayout(3));

		this.model = new CalcModelImpl();

		cp.add(l(), new RCPosition(1,1));

		JButton buttonEquals = new CalculatorButton("=", model);
		cp.add(buttonEquals, new RCPosition(1, 6));
		buttonEquals.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				double x, y, result;
				if(model.isActiveOperandSet())
					x = model.getActiveOperand();
				else {
					model.setValue(model.getValue());
					return;
				}

				y = model.getValue();

				DoubleBinaryOperator op = model.getPendingBinaryOperation();

				result = op.applyAsDouble(x, y);

				model.setValue(result);
				model.clearActiveOperand();
			}
		});

		JButton reciprocal = new ButtonUnaryOperation("1/x", model, Operations.RECIPROCAL, this);
		add(reciprocal, new RCPosition(2, 1));

		JButton log = new ButtonUnaryOperation("log", "10^x", model, Operations.LOG_10, Operations.POW_10, this);
		add(log, new RCPosition(3, 1));

		JButton sine = new ButtonUnaryOperation("sin", "arcsin", model, Operations.SINE, Operations.ARCSIN, this);
		add(sine, new RCPosition(2, 2));

		JButton cosine = new ButtonUnaryOperation("cos", "arccoc", model, Operations.COSINE, Operations.ARCCOS, this);
		add(cosine, new RCPosition(3, 2));

		JButton ln = new ButtonUnaryOperation("ln", "e^x", model, Operations.LOG_E, Operations.POW_E, this);
		add(ln, new RCPosition(4, 1));

		JButton tan = new ButtonUnaryOperation("tan", "arctan", model, Operations.TANGENT, Operations.ARCTAN, this);
		add(tan, new RCPosition(4, 2));

		JButton pow = new ButtonBinaryOperation("x^n", "x^(1/n)", model, Operations.POW, Operations.ROOT, this);
		add(pow, new RCPosition(5, 1));

		JButton ctg = new ButtonUnaryOperation("ctg", "arcctg", model, Operations.COTANGENT, Operations.ARCCTG, this);
		add(ctg, new RCPosition(5, 2));

		JButton seven = new ButtonDigits("7", model, this, 7);
		add(seven, new RCPosition(2, 3));

		JButton eight = new ButtonDigits("8", model, this, 8);
		add(eight, new RCPosition(2, 4));

		JButton nine = new ButtonDigits("9", model, this, 9);
		add(nine, new RCPosition(2, 5));

		JButton four = new ButtonDigits("4", model, this, 4);
		add(four, new RCPosition(3, 3));

		JButton five = new ButtonDigits("5", model, this, 5);
		add(five, new RCPosition(3, 4));

		JButton six = new ButtonDigits("6", model, this, 6);
		add(six, new RCPosition(3, 5));

		JButton one = new ButtonDigits("1", model, this, 1);
		add(one, new RCPosition(4, 3));

		JButton two = new ButtonDigits("2", model, this, 2);
		add(two, new RCPosition(4, 4));

		JButton three = new ButtonDigits("3", model, this, 3);
		add(three, new RCPosition(4, 5));

		JButton zero = new ButtonDigits("0", model, this, 0);
		add(zero, new RCPosition(5, 3));

		JButton changeSign = new CalculatorButton("+/-", model); 
		add(changeSign, new RCPosition(5, 4));
		changeSign.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				model.swapSign();
			}
		});


		JButton dot = new CalculatorButton(".", model);
		dot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				model.insertDecimalPoint();
			}
		});
		add(dot, new RCPosition(5, 5));

		JButton div = new ButtonBinaryOperation("/", model, Operations.DIVISION, this);
		add(div, new RCPosition(2, 6));

		JButton mul = new ButtonBinaryOperation("*", model, Operations.MULTIPLICATION, this);
		add(mul, new RCPosition(3, 6));

		JButton plus = new ButtonBinaryOperation("+", model, Operations.ADDITION, this);
		add(plus, new RCPosition(4, 6));

		JButton minus = new ButtonBinaryOperation("-", model, Operations.SUBTRACTION, this);
		add(minus, new RCPosition(5, 6));

		JButton clr = new CalculatorButton("clr", model);
		clr.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				model.clear();
			}
		});
		add(clr, new RCPosition(1, 7));	

		JButton reset = new CalculatorButton("res", model);
		reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				model.clearAll();
				stack = new ArrayList<>();
			}
		});
		add(reset, new RCPosition(2, 7));	

		JButton push = new CalculatorButton("push", model);
		push.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				stack.add(model.getValue());
				model.clear();
			}
		});
		add(push, new RCPosition(3, 7));	

		JButton pop = new CalculatorButton("pop", model);
		pop.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) { 
				if(!stack.isEmpty()) {
					double x = stack.remove(stack.size() - 1);
					model.setValue(x);
				} else {
					System.out.println("Stack is empty!");
				}
			}
		});
		add(pop, new RCPosition(4, 7));	


		JCheckBox checkBox = new JCheckBox("Inv");
		add(checkBox, new RCPosition(5, 7));
		checkBox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Component[] components = cp.getComponents();
				for(Component c: components) {
					if(c instanceof CalculatorButton) {
						((CalculatorButton) c).changeState();
					}
				}
				pack();
			}
		});



	}

	/**
	 * Method which creates label which represents a screen of the calculator. 
	 * @return JLabel which represents a screen of the calculator
	 */
	private JLabel l() {
		JLabel l = new JLabel(model.toString());
		l.setBackground(Color.YELLOW);
		l.setOpaque(true);
		l.setHorizontalAlignment(SwingConstants.RIGHT);

		model.addCalcValueListener(new CalcValueListener() {

			@Override
			public void valueChanged(CalcModel model) {
				String value = model.toString();
				l.setText(value);
			}
		});

		return l;
	}

	/**
	 * main method
	 * @param args arguments, not important
	 */

	public static void main(String[] args) {
		SwingUtilities.invokeLater(()->{
			new Calculator().setVisible(true);
		});
	}
}
