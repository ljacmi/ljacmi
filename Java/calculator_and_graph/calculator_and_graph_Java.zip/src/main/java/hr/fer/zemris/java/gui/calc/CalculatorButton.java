package hr.fer.zemris.java.gui.calc;

import java.awt.Color;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;

/**
 * Class which represents a button that can be used in a CalcModel calculator. Each button can have 
 * two states, starting and alternate state. State can be changed by calling changeState function. 
 * @author muham
 *
 */
public class CalculatorButton extends JButton {
	/**
	 * constant which keeps represents color of the calculator buttons
	 */
	public static final Color BUTTON_COLOR = new Color(204, 204, 255);
	/**
	 * reference to the CalcModel
	 */
	CalcModel model;
	
	/**
	 * flag which is set to true only if a button has two states 
	 */
	protected boolean twoStatesPresent = false;
	
	/**
	 * If a button has two states, then this flag is important to determine which
	 * state the button is currently at. If button has only one state, the value
	 * of this flag is irrelevant.
	 */
	protected boolean startingStateActive = true;
	
	/**
	 * Text shown on the button associated with the starting state.
	 */
	protected String name1;
	/**
	 * Text shown on the button associated with the alternate state.
	 */
	protected String name2;


	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * Constructor which takes only one text, which means button will have only one state.
	 * @param text1 text written on the button
	 * @param model reference to the CalcModel
	 */
	public CalculatorButton(String text1, CalcModel model) {
		this(text1, null, model);
	}
	
	/**
	 * Constructor which takes 2 possible texts, which means that the button
	 * will have two states. 
	 * 
	 * @param text1 text associated with starting state
	 * @param text2 text associate with alternate state
	 * @param model reference to CalcModel
	 */
	public CalculatorButton(String text1, String text2, CalcModel model) {
		super(text1);
		this.model = model;
		this.name1 = text1;
		this.name2 = text2;
		this.setBackground(BUTTON_COLOR);
		if(text2 != null)
			twoStatesPresent = true;
	}
	
	/**
	 * Method whose function is two change the state in which the button is. 
	 * If button has only one state, this function does nothing.
	 */


	public void changeState() {

		if(twoStatesPresent) {
			if(startingStateActive) {
				startingStateActive = false;
				this.setText(name2);
			} else {
				startingStateActive = true;
				this.setText(name1);
			}
		}
	}

}
