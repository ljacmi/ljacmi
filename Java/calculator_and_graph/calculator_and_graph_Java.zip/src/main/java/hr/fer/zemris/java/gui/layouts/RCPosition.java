package hr.fer.zemris.java.gui.layouts;



/**
 * Class represents positioning constraints in CalcLayout
 * @author muham
 *
 */

public class RCPosition {
	
	/**
	 * Number of row in which the component is. Minimal allowed value is 1, 
	 * and maximal is 5.
	 */
	private int row;
	
	/**
	 * Number of row in which the component is. Minimal allowed value is 1, 
	 * and maximal is 7.
	 */
	
	private int column;
	
	/**
	 * Private constructor which takes 2 arguments, number of row and column in which
	 * the component should be.
	 * @param row
	 * @param column
	 */
	
	
	
	public RCPosition(int row, int column) {
		
		if(row < 1 || row > 5 || column < 1 || column > 7 || 
				row == 1 && column > 1 && column < 6) {
			throw new CalcLayoutException();
		}
		
		
		this.row = row;
		this.column = column;
	}
	
	/**
	 * getter for row
	 * @return row
	 */
	
	public int getRow() {
		return row;
	}
	
	/**
	 * getter for column
	 * @return column
	 */
	
	public int getColumn() {
		return column;
	}
	
	/**
	 * Method-factory which returns new RCPosition.
	 * @param text String whose value is used to create new RCPosition object.
	 * It should be in following form: "row, column".
	 * @return new RCPosition
	 */
	
	public static RCPosition parse(String text) {
		String[] splitted =  text.split(",");
		int rows = Integer.parseInt(splitted[0]);
		int columns = Integer.parseInt(splitted[1].substring(1));
		
		return new RCPosition(rows, columns);
	}
}
