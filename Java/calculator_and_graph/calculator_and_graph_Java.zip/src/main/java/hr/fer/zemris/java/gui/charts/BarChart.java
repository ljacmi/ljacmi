package hr.fer.zemris.java.gui.charts;

import java.util.List;


/**
 * Class which is a model of BarChart.
 * @author muham
 *
 */
public class BarChart {
	/**
	 * List of pairs, where one half of the pair represents x value, 
	 * and other half represents y value.
	 */
	private List<XYValue> objects; 
	
	/**
	 * Description of x axis
	 */
	private String descriptionX;
	
	/**
	 * Description of y axis
	 */
	private String descriptionY; 
	
	/**
	 * Minimal value y can take.
	 */
	private int minY;
	
	/**
	 * Maximal value y can take.
	 */
	private int maxY; 
	
	/**
	 * Distance between two y values that are highlighted on the BarChart.
	 */
	private int distanceBetweenTwoY;
	
	
	/**
	 * Constructor for BarChart.
	 * @param objects List of pairs, where one half of the pair represents x value, 
	 * and other half represents y value.
	 * @param descriptionX  Description of x axis
	 * @param descriptionY  Description of y axis
	 * @param minY Minimal value y can take.
	 * @param maxY Maximal value y can take.
	 * @param distanceBetweenTwoY Distance between two y values that are highlighted on the BarChart.
	 * @throws IllegalArgumentException if minY is negative, maxY is not greater than minY or any of
	 * 	the y values specified in objects list is lesser than minY.
	 */
	public BarChart(List<XYValue> objects, String descriptionX, String descriptionY, 
			int minY, int maxY, int distanceBetweenTwoY) {
		if(minY < 0) 
			throw new IllegalArgumentException("Miminal y cannot be negative!");
		if(maxY <= minY) 
			throw new IllegalArgumentException("Maximal y must be greater than minimal y!");
		
		objects.forEach(o -> {
			if(o.getY() < minY) throw new IllegalArgumentException();
		});
		
		if(distanceBetweenTwoY >  maxY - minY) {
			maxY = minY + distanceBetweenTwoY;
		}
		
		
		this.objects = objects;
		this.descriptionX = descriptionX;
		this.descriptionY = descriptionY;
		this.minY = minY;
		this.maxY = maxY;
		this.distanceBetweenTwoY = distanceBetweenTwoY;
	}
	
	
	/**
	 * getter for objects
	 * @return list of all XYValue objects
	 */
	public List<XYValue> getObjects() {
		return objects;
	}
	
	/**
	 * getter for description of x axis
	 * @return description of x axis
	 */
	
	public String getDescriptionX() {
		return descriptionX;
	}
	
	/**
	 * getter for description of y axis
	 * @return description of y axis
	 */

	public String getDescriptionY() {
		return descriptionY;
	}
	
	/**
	 * getter for minimal value y can take
	 * @return minimal value y can take
	 */

	public int getMinY() {
		return minY;
	}
	
	/**
	 * getter for maximal value y can take
	 * @return maximal value y can take
	 */

	public int getMaxY() {
		return maxY;
	}
	
	/**
	 * getter for distance between two highlighted y values
	 * @return distance between two highlighted y values
	 */
	
	public int getDistanceBetweenTwoY() {
		return distanceBetweenTwoY;
	}
	
	
	
}
