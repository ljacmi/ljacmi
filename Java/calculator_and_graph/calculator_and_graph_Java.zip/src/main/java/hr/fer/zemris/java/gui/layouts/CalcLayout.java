package hr.fer.zemris.java.gui.layouts;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.Rectangle;



public class CalcLayout implements LayoutManager2{

	private static final int rows = 5;

	private static final int columns = 7;
	
	private int distanceBetweenRowsAndColumns;
	
	private Component[] components = new Component[rows * columns  - 4];
	
	
	private enum TypeOfSize {
		MINIMAL,
		PREFERRED,
		MAXIMAL
	}
	
	public CalcLayout(int distanceBetweenRowsAndColumns) {
		this.distanceBetweenRowsAndColumns = distanceBetweenRowsAndColumns;
	}
	
	public CalcLayout() {
		this.distanceBetweenRowsAndColumns = 0;
	}
	
	public void addLayoutComponent(String name, Component comp) {
		throw new UnsupportedOperationException();
	}

	public void removeLayoutComponent(Component comp) {
		System.out.println("RemoveLayoutComponent");
		for(int i = 0; i < components.length; i++) {
			if(components[i].equals(comp)) {
				components[i] = null;
				break;
			}
		}
		 
	}

	public Dimension preferredLayoutSize(Container parent) {
		return getSize(TypeOfSize.PREFERRED, parent);
	}

	public Dimension minimumLayoutSize(Container parent) {
		return getSize(TypeOfSize.MINIMAL, parent);
	}

	public void layoutContainer(Container parent) {
		Insets parentInsets = parent.getInsets();
		Rectangle parentBounds = parent.getBounds();
		
		
		
		int extraSpaceInPixelsWidth = (parentBounds.width - (parentInsets.left + parentInsets.right) 
				- 6 * distanceBetweenRowsAndColumns) % 7;
		
		int[] widthOfEachComponent = new int[7];
		int widthOfOneComponent = (parentBounds.width - (parentInsets.left + parentInsets.right) 
				- 6 * distanceBetweenRowsAndColumns) / 7;
		
		for(int i = 0; i < widthOfEachComponent.length; i++) {
			widthOfEachComponent[i] = widthOfOneComponent;
		}
		
		switch(extraSpaceInPixelsWidth) {
			case 0:
				break;
			case 1:
				widthOfEachComponent[3] += 1;
				break;
			case 2:
				widthOfEachComponent[2] += 1;
				widthOfEachComponent[4] += 1;
				break;
			case 3:
				widthOfEachComponent[1] += 1;
				widthOfEachComponent[3] += 1;
				widthOfEachComponent[5] += 1;
				break;
			case 4:
				widthOfEachComponent[2] += 1;
				widthOfEachComponent[3] += 1;
				widthOfEachComponent[5] += 1;
				widthOfEachComponent[6] += 1;
				break;
			case 5:
				widthOfEachComponent[0] += 1;
				widthOfEachComponent[1] += 1;
				widthOfEachComponent[3] += 1;
				widthOfEachComponent[4] += 1;
				widthOfEachComponent[6] += 1;
				break;
			case 6:
				widthOfEachComponent[0] += 1;
				widthOfEachComponent[1] += 1;
				widthOfEachComponent[2] += 1;
				widthOfEachComponent[4] += 1;
				widthOfEachComponent[5] += 1;
				widthOfEachComponent[6] += 1;
				break;	
		}
		
		
		
		int extraSpaceInPixelsHeight = (parentBounds.height - (parentInsets.top + parentInsets.bottom) 
				- 4 * distanceBetweenRowsAndColumns) % 5;
		
		int[] heightOfEachComponent = new int[5];
		int heightOfOneComponent = (parentBounds.height - (parentInsets.top + parentInsets.bottom) 
				- 4 * distanceBetweenRowsAndColumns) / 5;
		
		for(int i = 0; i < heightOfEachComponent.length; i++) {
			heightOfEachComponent[i] = heightOfOneComponent;
		}
		
		switch(extraSpaceInPixelsHeight) {
			case 0:
				break;
			case 1:
				heightOfEachComponent[2] += 1;
				break;
			case 2:
				heightOfEachComponent[1] += 1;
				heightOfEachComponent[3] += 1;
				break;
			case 3:
				heightOfEachComponent[0] += 1;
				heightOfEachComponent[2] += 1;
				heightOfEachComponent[4] += 1;
				break;
			case 4:
				heightOfEachComponent[0] += 1;
				heightOfEachComponent[1] += 1;
				heightOfEachComponent[3] += 1;
				heightOfEachComponent[4] += 1;
				break;
		}
		
		
		
		int corX = parentBounds.x + parentInsets.left;
		int corY = parentBounds.y + parentInsets.top;
		
		for(int i = 0; i < components.length; i++) {
			Component c = components[i];
			
			if(i == 0) {
				
				int widthOfFirstComponent = 0;
				
				for(int j = 0; j < 5; j++) {
					widthOfFirstComponent += widthOfEachComponent[j];
				}			
				
				widthOfFirstComponent += 4 * distanceBetweenRowsAndColumns; 
				if(c != null)
					c.setBounds(corX, corY, widthOfFirstComponent, heightOfEachComponent[0]);
				corX += widthOfFirstComponent + distanceBetweenRowsAndColumns;
			} else if(i % 7 + 4 == 6){ // last component in a row
				if(c != null)
					c.setBounds(corX, corY, widthOfEachComponent[(i + 4) % 7], heightOfEachComponent[(i + 4) % 5]);
				corX = parentBounds.x + parentInsets.left;
				corY += heightOfEachComponent[(i + 4) % 5] + distanceBetweenRowsAndColumns;
			} else {
				if(c != null)
					c.setBounds(corX, corY, widthOfEachComponent[(i + 4) % 7], heightOfEachComponent[(i + 4) % 5]);
				corX += widthOfEachComponent[(i + 4) % 7] + distanceBetweenRowsAndColumns;
			}
		}
		
	}

	public void addLayoutComponent(Component comp, Object constraints) {
		
		if(comp == null || constraints == null) throw new NullPointerException();
		
		if(!(constraints instanceof RCPosition || constraints instanceof String)) {
			throw new IllegalArgumentException();
		}
		
		RCPosition cons;
		if(constraints instanceof String) {
			try {
				cons = RCPosition.parse((String)constraints);
			} catch (NumberFormatException e) {
				throw new IllegalArgumentException();
			}
		} else {
			cons = (RCPosition)constraints;
		}
		
		int indexInArray = calculateIndexInComponentsArray(cons); 
		
		if(components[indexInArray] == null)
			components[indexInArray] = comp;
		else 
			throw new CalcLayoutException();
		
	}

	public Dimension maximumLayoutSize(Container target) {
		return getSize(TypeOfSize.MAXIMAL, target);
	}

	public float getLayoutAlignmentX(Container target) {
		return 0;
	}

	public float getLayoutAlignmentY(Container target) {
		return 0;
	}

	public void invalidateLayout(Container target) {
		// TODO Auto-generated method stub
		
	}
	
	
	private Dimension getSize(TypeOfSize typeOfSize, Container parent) {
		int height = 0;
		int width = 0;
		int maxHeight = 0;
		int maxWidth = 0;
		
		for(Component c: parent.getComponents()) {
			Dimension d = null;
			if(typeOfSize == TypeOfSize.PREFERRED) d = c.getPreferredSize();
			else if (typeOfSize == TypeOfSize.MAXIMAL) d = c.getMaximumSize();
			else if (typeOfSize == TypeOfSize.MINIMAL) d = c.getMinimumSize();
			if(d.height > maxHeight) {
				maxHeight = d.height;
			}

			if(c.equals(components[0])) {
				d.width = (d.width - 4 * distanceBetweenRowsAndColumns) / 5;
			}
			
			if(d.width > maxWidth) {
				maxWidth = d.width;
			}
		}
		
		Insets insets = parent.getInsets();
		
		width = insets.left + insets.right + 7 * maxWidth + 6 * distanceBetweenRowsAndColumns;
		height = insets.top + insets.bottom + 5 * maxHeight + 4 * distanceBetweenRowsAndColumns;
		
		return new Dimension(width, height);
	}
	
	private int calculateIndexInComponentsArray(RCPosition constraint) {
		if(constraint.getRow() == 1 && constraint.getColumn() < 6) return 0;
		
		return (constraint.getRow() - 1) * 7 + constraint.getColumn() - 5; //5 = 4 + 1, 4 for size of element 1, and 1 because indexes start from 0
	}

}
