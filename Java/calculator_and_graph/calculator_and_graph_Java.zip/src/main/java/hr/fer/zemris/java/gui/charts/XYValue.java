package hr.fer.zemris.java.gui.charts;


/**
 * Class which keeeps two values, x and y value. 
 * @author muham
 *
 */
public class XYValue {
	/**
	 * keeps x value
	 */
	private int x;
	/**
	 * keeps y value
	 */
	private int y;
	
	/**
	 * constructor which takes 2 arguments, x and y value
	 * @param x x value
	 * @param y y value
	 */
	public XYValue(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * getter for x value
	 * @return x value
	 */
	
	public int getX() {
		return x;
	}
	
	/**
	 * getter for y value
	 * @return y value
	 */
	public int getY() {
		return y;
	}
	
}
