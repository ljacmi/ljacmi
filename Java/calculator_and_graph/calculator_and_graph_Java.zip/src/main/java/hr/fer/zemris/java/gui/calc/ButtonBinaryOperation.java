package hr.fer.zemris.java.gui.calc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.function.DoubleBinaryOperator;

import hr.fer.zemris.java.gui.calc.model.CalcModel;


/**
 * Class which represents a button whose functionality is associated with some 
 * binary operation.
 * @author muham
 *
 */
public class ButtonBinaryOperation extends CalculatorButton{

	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor which takes only one binary operation.
	 * @param text text shown on the button
	 * @param model reference to the CalcModel
	 * @param operator operation invoked by clicking on the button
	 * @param c reference to calculator
	 */
	
	public ButtonBinaryOperation(String text, CalcModel model, DoubleBinaryOperator operator, Calculator c) {
		this(text, null, model, operator, null, c);

	}
	
	/**
	 * Constructor which takes two possible operations and two possible text
	 * that are written on the button. Each operation is associated with one text and 
	 * each operation can be invoked by clicking on the button. Which one will be invoked
	 * depends on the state of startingStateActive flag defined in the CalculatorButton class.
	 * @param text1 text shown on the button in starting state
	 * @param text2 text shown on the button in alternate state
	 * @param model reference to the CalcModel
	 * @param operator1 operation that can be invoked in starting state
	 * @param operator2 operation that can be invoked in alternate state
	 * @param c reference to calculator
	 */
	public ButtonBinaryOperation(String text1, String text2, CalcModel model, DoubleBinaryOperator operator1, DoubleBinaryOperator operator2, Calculator c) {
		super(text1, text2, model);

		if(operator2 != null)
			twoStatesPresent = true;

		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				double x = model.getValue();

				if(model.isActiveOperandSet()) {
					double y = model.getActiveOperand();
					DoubleBinaryOperator op = model.getPendingBinaryOperation();
					double result = op.applyAsDouble(y, x);
					model.setActiveOperand(result);
					model.setValue(result);
				} else {
					model.setActiveOperand(x);
					model.setValue(x);
				}
				
				
				if(twoStatesPresent && !startingStateActive) {
					model.setPendingBinaryOperation(operator2);
				} else {
					model.setPendingBinaryOperation(operator1);
				}

			}

		});
	}
}
