package hr.fer.zemris.java.gui.charts;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JComponent;

/**
 * Class which represents a BarChart component.
 * @author muham
 *
 */

public class BarChartComponent extends JComponent{

	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;


	/**
	 * Reference to the model of BarChart that needs to be drawn.
	 */
	BarChart chart;
	
	/**
	 * distance between y axis and y values 
	 */
	
	private static final int DISTANCE_BETWEEN_Y_AXIS_AND_Y_VALUES = 10;
	
	/**
	 * length of an arrow of the axis
	 */
	
	private static final int ARRROW_LENGTH = 20;
	
	/**
	 * width of an arrow of the axis
	 */
	
	private static final int ARRROW_WIDTH = 10;
	
	/**
	 * distance between description of y axis and y values
	 */
	
	private static final int DISTANCE_BETWEEN_DESCRIPTION_OF_Y_AXIS_AND_Y_VALUES = 15;
	
	/**
	 * length of lines used for marking highlighted values
	 */
	private static final int LENGTH_OF_SMALL_LINES = 7;

	public BarChartComponent(BarChart chart) {
		this.chart = chart;
		
	}



	
	@Override
	protected void paintComponent(Graphics g) {
		
		
		Graphics2D g2D = (Graphics2D) g;

		int xOffset = 50, yOffset = 30;

		int spaceNeededForYDescriptionLength = g2D.getFontMetrics().stringWidth(String.valueOf(chart.getDescriptionY()));
		int heightOfText = g2D.getFontMetrics().getHeight();
		int ascentOfText = g2D.getFontMetrics().getAscent();
		int spaceNeededForXDescriptionLength = g2D.getFontMetrics().stringWidth(String.valueOf(chart.getDescriptionX()));
		
		
		int availableHeight = getHeight();
		int availableWidth= getWidth();
		int lengthOfYAxis = availableHeight - 10 - heightOfText - 10 - ARRROW_LENGTH - yOffset * 2;
		
		int positionOfZeroY = availableHeight - yOffset - heightOfText - 10 - heightOfText - 10;
		
		
		
		
		int distanceBetweenMinAndMax = chart.getMaxY() - chart.getMinY();
		int spaceNeededForYValuesWidth = g2D.getFontMetrics().stringWidth(String.valueOf(chart.getMaxY()));
		int numberOfXValues = chart.getObjects().size();
		int lengthOfXAxis = availableWidth - 2 * xOffset - heightOfText - 10 - spaceNeededForYValuesWidth - 10;
		
		
		int heightOfOneYRegion = (lengthOfYAxis) / ((chart.getMaxY() - chart.getMinY()) / chart.getDistanceBetweenTwoY());
		int widthOfOneXRegion = lengthOfXAxis / numberOfXValues;
		int numberOfYValues = distanceBetweenMinAndMax / chart.getDistanceBetweenTwoY();
		
		

		//draw description of y axis
		AffineTransform at = new AffineTransform(g2D.getTransform());
		at.rotate(-Math.PI / 2);
		g2D.setTransform(at);
		g2D.drawString(chart.getDescriptionY(), -xOffset - lengthOfYAxis/2 - spaceNeededForYDescriptionLength/2, xOffset);
		at.rotate(Math.PI / 2);
		g2D.setTransform(at);
		
		
		

		//draw y values
		int xcor = xOffset + DISTANCE_BETWEEN_DESCRIPTION_OF_Y_AXIS_AND_Y_VALUES;

		for(int i = 0; i < numberOfYValues + 1; i++) {
			String value = String.valueOf(chart.getMinY() + i * chart.getDistanceBetweenTwoY());
			g.drawString(value, xcor + (spaceNeededForYValuesWidth - g2D.getFontMetrics().stringWidth(value)), positionOfZeroY + ascentOfText/2 - i * heightOfOneYRegion );
			g.drawLine(xcor + spaceNeededForYValuesWidth + 3, positionOfZeroY - i * heightOfOneYRegion,
					xcor + spaceNeededForYValuesWidth + DISTANCE_BETWEEN_Y_AXIS_AND_Y_VALUES , positionOfZeroY - i * heightOfOneYRegion);
		}

		//x and y axis
		xcor = xcor + spaceNeededForYValuesWidth + DISTANCE_BETWEEN_Y_AXIS_AND_Y_VALUES;
		
		
		g2D.drawLine(xcor, positionOfZeroY, xcor, positionOfZeroY - lengthOfYAxis);
		g2D.drawLine(xcor, positionOfZeroY, xcor + lengthOfXAxis, positionOfZeroY);



		//draw x values

		List<XYValue> list = chart.getObjects();
		for(int i = 0; i < list.size(); i++) {
			g2D.drawString(String.valueOf(i + 1), xcor + (widthOfOneXRegion * i) + widthOfOneXRegion/2, positionOfZeroY + 10 + heightOfText);
			int xcorOfLine = xcor + (widthOfOneXRegion * i);
			g2D.drawLine(xcorOfLine, positionOfZeroY, xcorOfLine, positionOfZeroY + LENGTH_OF_SMALL_LINES);
		}


		//draw description of x axis

		xcor = xcor + lengthOfXAxis / 2 - spaceNeededForXDescriptionLength/2;

		g2D.drawString(chart.getDescriptionX(), xcor , availableHeight - yOffset);


		//draw rectangles
		xcor = xcor - lengthOfXAxis / 2 + spaceNeededForXDescriptionLength/2;
		g2D.setColor(Color.orange);

		for(int i = 0; i < list.size(); i++) {
			g2D.fillRect(xcor + 1 + widthOfOneXRegion * i, positionOfZeroY -(list.get(i).getY()) * heightOfOneYRegion/chart.getDistanceBetweenTwoY() - 1, 
					widthOfOneXRegion - 1, (list.get(i).getY()) * heightOfOneYRegion/chart.getDistanceBetweenTwoY());
		}

		//draw arrows
		xcor = xOffset + DISTANCE_BETWEEN_Y_AXIS_AND_Y_VALUES + spaceNeededForYValuesWidth + DISTANCE_BETWEEN_DESCRIPTION_OF_Y_AXIS_AND_Y_VALUES;
		g2D.setColor(Color.black);
		g2D.fillPolygon(new int[] {xcor - ARRROW_WIDTH, xcor, xcor + ARRROW_WIDTH}, new int[] {positionOfZeroY - lengthOfYAxis, positionOfZeroY - lengthOfYAxis - ARRROW_LENGTH, positionOfZeroY - lengthOfYAxis}, 3);
		
		

		xcor += lengthOfXAxis + ARRROW_LENGTH;
		g2D.fillPolygon(new int[] {xcor - ARRROW_LENGTH, xcor, xcor - ARRROW_LENGTH}, new int[] {positionOfZeroY + ARRROW_WIDTH, positionOfZeroY, positionOfZeroY - ARRROW_WIDTH}, 3);
		
		
	}
	


}


