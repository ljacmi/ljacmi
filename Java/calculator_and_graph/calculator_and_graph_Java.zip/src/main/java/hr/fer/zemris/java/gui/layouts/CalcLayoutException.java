package hr.fer.zemris.java.gui.layouts;

public class CalcLayoutException extends RuntimeException{

	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;

}
