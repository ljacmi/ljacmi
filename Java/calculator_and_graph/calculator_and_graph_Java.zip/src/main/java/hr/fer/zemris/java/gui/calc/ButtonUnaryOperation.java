package hr.fer.zemris.java.gui.calc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.function.DoubleUnaryOperator;



import hr.fer.zemris.java.gui.calc.model.CalcModel;

public class ButtonUnaryOperation extends CalculatorButton{

	/**
	 * default serialization
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * reference to the operation that can be invoked in starting state
	 */
	private DoubleUnaryOperator unaryOperator1;
	
	/**
	 * reference to the operation that can be invoked in alternate state
	 */
	private DoubleUnaryOperator unaryOperator2;
	
	/**
	 * Constructor which takes only one binary operation.
	 * @param text text shown on the button
	 * @param model reference to the CalcModel
	 * @param operator operation invoked by clicking on the button
	 * @param c reference to calculator
	 */
	
	public ButtonUnaryOperation(String text1, CalcModel model, DoubleUnaryOperator operator, Calculator c) {
		this(text1, null, model, operator, null, c);

	}
	
	/**
	 * Constructor which takes two possible operations and two possible text
	 * that are written on the button. Each operation is associated with one text and 
	 * each operation can be invoked by clicking on the button. Which one will be invoked
	 * depends on the state of startingStateActive flag defined in the CalculatorButton class.
	 * @param text1 text shown on the button in starting state
	 * @param text2 text shown on the button in alternate state
	 * @param model reference to the CalcModel
	 * @param operator1 operation that can be invoked in starting state
	 * @param operator2 operation that can be invoked in alternate state
	 * @param c reference to calculator
	 */

	public ButtonUnaryOperation(String text1, String text2, CalcModel model, DoubleUnaryOperator operator1, DoubleUnaryOperator operator2, Calculator c) {
		super(text1, text2, model);
		this.unaryOperator1 = operator1;
		this.unaryOperator2 = operator2;
		if(operator2 != null)
			twoStatesPresent = true;
		
		addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				double x = model.getValue();
				double result;

				if(twoStatesPresent && !startingStateActive) {
					result = unaryOperator2.applyAsDouble(x);
				} else {
					result = unaryOperator1.applyAsDouble(x);
				}
				
				model.setValue(result);
			}
		});
	}

}


