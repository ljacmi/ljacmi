package hr.fer.zemris.java.gui.calc;

import java.util.LinkedList;
import java.util.List;
import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleUnaryOperator;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalcValueListener;
import hr.fer.zemris.java.gui.calc.model.CalculatorInputException;

/**
 * Implementation of the CalcModel.
 * @author muham
 *
 */
public class CalcModelImpl implements CalcModel {
	/**
	 * True if the model is editable, which means user can input new digits,
	 * decimal dot or change sign of the number.
	 */
	boolean isEditable = true;
	/**
	 * Flag which is set to true if and only if the number is positive.
	 */
	boolean numberIsPositive = true;

	/**
	 * Keeps the value of the inputed number. 
	 */

	String entry = "";

	/**
	 * 
	 * Keeps the value of the inputed number in numeric form. 
	 */

	Double entryNumerical = null;

	/**
	 * Last value acquired by invoking freezeValue method. 
	 */

	String frozenValue = null;

	/**
	 * If there is pending binary operation, this variable keeps
	 * the value of the operand which has already been inputed.
	 */
	Double activeOperand = null;

	/**
	 * Keeps the reference to pending binary operation.
	 */
	DoubleBinaryOperator pendingOperation = null;

	/**
	 * List of all CalcValueListeners which are interested in any change of entry 
	 * variable.
	 */

	List<CalcValueListener> listeners = new LinkedList<>();

	/**
	 * default constructor
	 */
	public CalcModelImpl() {
	}

	@Override
	public void addCalcValueListener(CalcValueListener l) {
		listeners.add(l);

	}

	@Override
	public void removeCalcValueListener(CalcValueListener l) {
		listeners.remove(l);
	}

	@Override
	public double getValue() {
		if(entryNumerical == null) {
			return 0;
		}
		return entryNumerical;
	}

	@Override
	public void setValue(double value) {
		entryNumerical = value;
		entry = String.valueOf((value));
		isEditable = false;
		informAllListeners();
	}

	@Override
	public boolean isEditable() {
		return isEditable;
	}

	@Override
	public void clear() {
		entry = "";
		entryNumerical = null;
		isEditable = true;
		numberIsPositive = true;
		informAllListeners();
	}

	@Override
	public void clearAll() {
		clear();
		activeOperand = null;
		pendingOperation = null;
		frozenValue = null;

	}

	@Override
	public void swapSign() throws CalculatorInputException {
		if(!isEditable) throw new CalculatorInputException();
		if(numberIsPositive) {
			entry = "-" + entry;
			try {
				entryNumerical = Double.parseDouble(entry);
			} catch(Exception e){
				//do nothing
			}
		} else {
			entry = entry.substring(1);
			try {
				entryNumerical = Double.parseDouble(entry);
			} catch(Exception e){
				//do nothing
			}
		}
		numberIsPositive = !numberIsPositive;
		informAllListeners();
	}

	@Override
	public void insertDecimalPoint() throws CalculatorInputException {
		if(!isEditable) throw new CalculatorInputException();
		if(entry.contains(".")) {
			throw new CalculatorInputException("Decimal dot is already present!");
		}
		if(entry.equals("") || entry.equals("-"))
			throw new CalculatorInputException("Decimal dot cannot be added if no digits have"
					+ "been added first!");
		entry += ".";
		informAllListeners();

	}

	@Override
	public void insertDigit(int digit) throws CalculatorInputException, IllegalArgumentException {
		if(!isEditable) throw new CalculatorInputException();
		if(digit != 0 || !entry.equals("0")) {
			
			double entryNumerical2 = Double.parseDouble(entry + digit);
			if(entryNumerical2 > Double.MAX_VALUE) throw new CalculatorInputException("Adding that digit would make number to big!");
			if(entry.equals("0")) 
				entry = String.valueOf(digit);
			else 
				entry += String.valueOf(digit);
			entryNumerical = entryNumerical2;
			informAllListeners();
		}
	}

	@Override
	public boolean isActiveOperandSet() {
		return activeOperand != null;
	}

	@Override
	public double getActiveOperand() throws IllegalStateException {
		if(activeOperand == null) throw new IllegalStateException();
		return activeOperand;
	}

	@Override
	public void setActiveOperand(double activeOperand) {
		this.activeOperand = activeOperand; 

	}

	@Override
	public void clearActiveOperand() {
		this.activeOperand = null;
	}

	@Override
	public DoubleBinaryOperator getPendingBinaryOperation() {
		return pendingOperation;
	}

	@Override
	public void setPendingBinaryOperation(DoubleBinaryOperator op) {
		this.pendingOperation = op;
	}

	@Override
	public String toString() {
		freezeValue();
		return frozenValue;
	}

	public double calculateUnaryOperation(DoubleUnaryOperator op) {	
		return op.applyAsDouble(entryNumerical);
	}

	public double calculateBinaryOperation(double operand2, DoubleBinaryOperator op) {
		double result = op.applyAsDouble(activeOperand, operand2);
		clearActiveOperand();
		setPendingBinaryOperation(null);
		return result;
	}


	/**
	 * Saves the current value of the entry variable. If entry is equal to "", then
	 * 0 or -0 is returned(depending on the isPositive variable).
	 */
	public void freezeValue() {
		if(entry.equals("")) {
			frozenValue = "0";
		} else if(entry.equals("-")) {
			frozenValue = "-0";
		} else {
			frozenValue = entry;
		}
	}

	/**
	 * Method that should be invoked by every set method which changes entry variable
	 * (after the change).
	 * It will inform all CalcValueListeners about this change.
	 */

	public void informAllListeners() {
		for(CalcValueListener l: listeners) {
			l.valueChanged(this);
		}
	}

}
